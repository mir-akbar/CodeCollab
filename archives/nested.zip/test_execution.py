#!/usr/bin/env python3
"""
Code Execution Test File
------------------------
This file contains various Python operations to test code execution.
"""

import math
import datetime
import sys
import platform
import os
from collections import Counter


def test_basic_operations():
    """Test basic arithmetic operations."""
    print("\n=== Basic Operations ===")
    print(f"Addition: 5 + 3 = {5 + 3}")
    print(f"Subtraction: 10 - 4 = {10 - 4}")
    print(f"Multiplication: 6 * 7 = {6 * 7}")
    print(f"Division: 20 / 5 = {20 / 5}")
    print(f"Integer Division: 20 // 3 = {20 // 3}")
    print(f"Modulo: 20 % 7 = {20 % 7}")
    print(f"Exponentiation: 2 ** 8 = {2 ** 8}")


def test_string_operations():
    """Test string manipulation operations."""
    print("\n=== String Operations ===")
    test_string = "Python is awesome!"
    print(f"Original string: '{test_string}'")
    print(f"Length: {len(test_string)}")
    print(f"Uppercase: '{test_string.upper()}'")
    print(f"Lowercase: '{test_string.lower()}'")
    print(f"Replace: '{test_string.replace('awesome', 'amazing')}'")
    print(f"Split: {test_string.split()}")
    print(f"First 6 characters: '{test_string[:6]}'")


def test_data_structures():
    """Test various data structures."""
    print("\n=== Data Structures ===")
    
    # List
    my_list = [1, 2, 3, 4, 5]
    print(f"List: {my_list}")
    my_list.append(6)
    print(f"After append: {my_list}")
    my_list.insert(0, 0)
    print(f"After insert: {my_list}")
    
    # Dictionary
    my_dict = {'name': 'Python', 'version': '3.9', 'type': 'Programming Language'}
    print(f"Dictionary: {my_dict}")
    my_dict['creator'] = 'Guido van Rossum'
    print(f"After adding key: {my_dict}")
    
    # Set
    my_set = {1, 2, 3, 4, 5, 5, 4, 3}
    print(f"Set (notice duplicates removed): {my_set}")
    my_set.add(6)
    print(f"After adding element: {my_set}")
    
    # Tuple
    my_tuple = (1, 2, 3, 'a', 'b')
    print(f"Tuple: {my_tuple}")
    print(f"Tuple element access: {my_tuple[2]}")


def calculate_fibonacci(n):
    """Calculate the Fibonacci sequence up to n terms."""
    fib_sequence = [0, 1]
    for i in range(2, n):
        fib_sequence.append(fib_sequence[i-1] + fib_sequence[i-2])
    return fib_sequence


def test_control_flow():
    """Test control flow statements."""
    print("\n=== Control Flow ===")
    
    # If-elif-else
    x = 10
    if x > 15:
        print("x is greater than 15")
    elif x > 5:
        print("x is greater than 5 but not greater than 15")
    else:
        print("x is 5 or less")
    
    # For loop
    print("Counting from 1 to 5:")
    for i in range(1, 6):
        print(i, end=" ")
    print()
    
    # While loop
    print("While loop counting down from 5:")
    count = 5
    while count > 0:
        print(count, end=" ")
        count -= 1
    print()
    
    # List comprehension
    squares = [i**2 for i in range(1, 6)]
    print(f"Squares using list comprehension: {squares}")


def test_exception_handling():
    """Test exception handling."""
    print("\n=== Exception Handling ===")
    
    try:
        result = 10 / 0
    except ZeroDivisionError as e:
        print(f"Caught an exception: {e}")
    
    try:
        number = int("not_a_number")
    except ValueError as e:
        print(f"Caught another exception: {e}")
    
    try:
        value = "hello"
        print(f"No exception here, value is: {value}")
    except Exception as e:
        print("This won't execute")
    finally:
        print("Finally block always executes")


def test_advanced_math():
    """Test some math functions from the math module."""
    print("\n=== Advanced Math ===")
    print(f"Square root of 16: {math.sqrt(16)}")
    print(f"Sine of 30 degrees: {math.sin(math.radians(30))}")
    print(f"Cosine of 60 degrees: {math.cos(math.radians(60))}")
    print(f"Ceiling of 4.3: {math.ceil(4.3)}")
    print(f"Floor of 4.8: {math.floor(4.8)}")
    print(f"Pi constant: {math.pi}")
    print(f"Factorial of 5: {math.factorial(5)}")


def test_system_info():
    """Display system information."""
    print("\n=== System Information ===")
    print(f"Python Version: {sys.version}")
    print(f"Platform: {platform.platform()}")
    print(f"Current Directory: {os.getcwd()}")
    print(f"Current Date/Time: {datetime.datetime.now()}")


def word_frequency(text):
    """Calculate word frequency in the provided text."""
    words = text.lower().split()
    return Counter(words)


def test_frequency_analysis():
    """Test counter for frequency analysis."""
    print("\n=== Text Analysis ===")
    sample_text = "This is a sample text. This text is used for demonstration purposes. Sample text can be any text."
    frequencies = word_frequency(sample_text)
    print("Word frequencies:")
    for word, count in frequencies.most_common():
        print(f"  {word}: {count}")


def main():
    """Main function to run all tests."""
    print("PYTHON CODE EXECUTION TEST")
    print("==========================")
    
    test_basic_operations()
    test_string_operations()
    test_data_structures()
    test_control_flow()
    test_exception_handling()
    test_advanced_math()
    test_system_info()
    test_frequency_analysis()
    
    # Test Fibonacci
    n = 10
    fib = calculate_fibonacci(n)
    print(f"\n=== Fibonacci Sequence ===")
    print(f"First {n} Fibonacci numbers: {fib}")

    print("\n==========================")
    print("All tests completed successfully!")


if __name__ == "__main__":
    main()

/**
 * JavaScript Code Execution Test File
 * ----------------------------------
 * This file contains various JavaScript operations to test code execution.
 * Run with: node code_execution_test.js
 */

// Basic utility for section headers
function printSection(title) {
    console.log(`\n=== ${title} ===`);
}

// Test basic operations
function testBasicOperations() {
    printSection("Basic Operations");
    
    // Arithmetic operations
    console.log(`Addition: 5 + 3 = ${5 + 3}`);
    console.log(`Subtraction: 10 - 4 = ${10 - 4}`);
    console.log(`Multiplication: 6 * 7 = ${6 * 7}`);
    console.log(`Division: 20 / 5 = ${20 / 5}`);
    console.log(`Integer Division (Math.floor): Math.floor(20 / 3) = ${Math.floor(20 / 3)}`);
    console.log(`Modulo: 20 % 7 = ${20 % 7}`);
    console.log(`Exponentiation: 2 ** 8 = ${2 ** 8}`);
    
    // Assignment operators
    let x = 10;
    console.log(`Initial x value: ${x}`);
    x += 5;
    console.log(`After x += 5: ${x}`);
    x -= 3;
    console.log(`After x -= 3: ${x}`);
    x *= 2;
    console.log(`After x *= 2: ${x}`);
    x /= 4;
    console.log(`After x /= 4: ${x}`);
    
    // Comparison operators
    console.log(`5 == '5': ${5 == '5'}`);  // True (loose equality)
    console.log(`5 === '5': ${5 === '5'}`); // False (strict equality)
    console.log(`5 != 8: ${5 != 8}`);
    console.log(`5 < 10: ${5 < 10}`);
    console.log(`5 >= 5: ${5 >= 5}`);
    
    // Logical operators
    console.log(`true && false: ${true && false}`);
    console.log(`true || false: ${true || false}`);
    console.log(`!true: ${!true}`);
    
    // Nullish coalescing
    const nullValue = null;
    const undefinedValue = undefined;
    const someValue = "Hello";
    console.log(`nullValue ?? "Default": ${nullValue ?? "Default"}`);
    console.log(`undefinedValue ?? "Default": ${undefinedValue ?? "Default"}`);
    console.log(`someValue ?? "Default": ${someValue ?? "Default"}`);
    
    // Optional chaining
    const user = {
        profile: {
            name: "John"
        }
    };
    const emptyUser = {};
    console.log(`user?.profile?.name: ${user?.profile?.name}`);
    console.log(`emptyUser?.profile?.name: ${emptyUser?.profile?.name}`);
}

// Test string operations
function testStringOperations() {
    printSection("String Operations");
    
    const testString = "JavaScript is awesome!";
    console.log(`Original string: '${testString}'`);
    console.log(`Length: ${testString.length}`);
    console.log(`Uppercase: '${testString.toUpperCase()}'`);
    console.log(`Lowercase: '${testString.toLowerCase()}'`);
    console.log(`Replace: '${testString.replace("awesome", "amazing")}'`);
    console.log(`Split: ${JSON.stringify(testString.split(" "))}`);
    console.log(`First 10 characters: '${testString.substring(0, 10)}'`);
    console.log(`Includes 'Script': ${testString.includes("Script")}`);
    console.log(`StartsWith 'Java': ${testString.startsWith("Java")}`);
    console.log(`EndsWith '!': ${testString.endsWith("!")}`);
    console.log(`indexOf 'is': ${testString.indexOf("is")}`);
    
    // Template literals
    const name = "JavaScript";
    const age = 26; // First appeared in 1995
    console.log(`Template literal: ${name} is approximately ${age} years old.`);
    
    // Multi-line strings
    const multiLine = `This is a
multi-line string
using template literals.`;
    console.log(`Multi-line string: \n${multiLine}`);
    
    // String padding
    console.log(`'42'.padStart(5, '0'): ${'42'.padStart(5, '0')}`);
    console.log(`'Hello'.padEnd(10, '.'): ${'Hello'.padEnd(10, '.')}`);
    
    // Trim methods
    const paddedString = "   spaced out   ";
    console.log(`Original padded string: '${paddedString}'`);
    console.log(`After trim: '${paddedString.trim()}'`);
    console.log(`After trimStart: '${paddedString.trimStart()}'`);
    console.log(`After trimEnd: '${paddedString.trimEnd()}'`);
}

// Test variables and data types
function testVariablesAndDataTypes() {
    printSection("Variables and Data Types");
    
    // Variable declarations
    var oldWay = "var declaration";
    let modern = "let declaration";
    const constant = "const declaration";
    
    console.log(`Different variable declarations: ${oldWay}, ${modern}, ${constant}`);
    
    // Data types
    const numberValue = 42;
    const stringValue = "Hello";
    const booleanValue = true;
    const nullValue = null;
    const undefinedValue = undefined;
    const symbolValue = Symbol("unique");
    const bigIntValue = BigInt(9007199254740991);
    
    console.log(`Number: ${numberValue}, type: ${typeof numberValue}`);
    console.log(`String: ${stringValue}, type: ${typeof stringValue}`);
    console.log(`Boolean: ${booleanValue}, type: ${typeof booleanValue}`);
    console.log(`Null: ${nullValue}, type: ${typeof nullValue}`); // quirk: type is "object"
    console.log(`Undefined: ${undefinedValue}, type: ${typeof undefinedValue}`);
    console.log(`Symbol: ${String(symbolValue)}, type: ${typeof symbolValue}`);
    console.log(`BigInt: ${bigIntValue}, type: ${typeof bigIntValue}`);
    
    // Object literals
    const person = {
        name: "John",
        age: 30,
        greet: function() {
            return `Hello, my name is ${this.name}`;
        }
    };
    
    console.log(`Object: ${JSON.stringify(person, (key, value) => 
        typeof value === 'function' ? '[Function]' : value, 2)}`);
    console.log(`Object method result: ${person.greet()}`);
    
    // Arrays
    const fruits = ["Apple", "Banana", "Cherry"];
    console.log(`Array: ${JSON.stringify(fruits)}, type: ${typeof fruits}`);
    console.log(`Array.isArray(fruits): ${Array.isArray(fruits)}`);
    
    // Date
    const now = new Date();
    console.log(`Current date: ${now}, type: ${typeof now}`);
}

// Test data structures (arrays and objects)
function testDataStructures() {
    printSection("Data Structures");
    
    // Arrays
    const myArray = [1, 2, 3, 4, 5];
    console.log(`Array: ${myArray}`);
    
    // Array methods
    myArray.push(6);
    console.log(`After push: ${myArray}`);
    
    myArray.unshift(0);
    console.log(`After unshift: ${myArray}`);
    
    const poppedValue = myArray.pop();
    console.log(`Popped value: ${poppedValue}, Array after pop: ${myArray}`);
    
    const shiftedValue = myArray.shift();
    console.log(`Shifted value: ${shiftedValue}, Array after shift: ${myArray}`);
    
    // Slice and splice
    console.log(`Slice (1,3): ${myArray.slice(1, 3)}`);
    console.log(`Original array after slice: ${myArray}`); // Unchanged
    
    const splicedItems = myArray.splice(1, 2, 'a', 'b');
    console.log(`Spliced items: ${splicedItems}, Array after splice: ${myArray}`);
    
    // Objects
    const myObject = {
        name: "JavaScript",
        year: 1995,
        features: ["First-class functions", "Dynamic typing", "Prototype-based OOP"]
    };
    
    console.log(`Object: ${JSON.stringify(myObject, null, 2)}`);
    
    // Object operations
    myObject.version = "ES2022";
    console.log(`After adding property: ${JSON.stringify(myObject, null, 2)}`);
    
    delete myObject.year;
    console.log(`After deleting property: ${JSON.stringify(myObject, null, 2)}`);
    
    // Object methods
    console.log(`Object.keys: ${Object.keys(myObject)}`);
    console.log(`Object.values: ${JSON.stringify(Object.values(myObject))}`);
    console.log(`Object.entries: ${JSON.stringify(Object.entries(myObject))}`);
    
    // Spread operator with arrays and objects
    const arr1 = [1, 2, 3];
    const arr2 = [4, 5, 6];
    const mergedArray = [...arr1, ...arr2];
    console.log(`Merged array with spread: ${mergedArray}`);
    
    const obj1 = { a: 1, b: 2 };
    const obj2 = { c: 3, d: 4 };
    const mergedObject = { ...obj1, ...obj2 };
    console.log(`Merged object with spread: ${JSON.stringify(mergedObject)}`);
    
    // Maps
    const myMap = new Map();
    myMap.set('key1', 'value1');
    myMap.set('key2', 'value2');
    myMap.set(123, 'numeric key');
    
    console.log(`Map size: ${myMap.size}`);
    console.log(`Map.get('key1'): ${myMap.get('key1')}`);
    console.log(`Map.has('key2'): ${myMap.has('key2')}`);
    console.log(`Map.has('nonexistent'): ${myMap.has('nonexistent')}`);
    
    console.log(`Map entries:`);
    for (const [key, value] of myMap) {
        console.log(`  ${key}: ${value}`);
    }
    
    // Sets
    const mySet = new Set([1, 2, 3, 3, 3, 4, 5, 5]);
    console.log(`Set (notice duplicates removed): ${[...mySet]}`);
    mySet.add(6);
    console.log(`After adding element: ${[...mySet]}`);
    console.log(`Set.has(4): ${mySet.has(4)}`);
    mySet.delete(1);
    console.log(`After deleting element: ${[...mySet]}`);
}

// Test control flow
function testControlFlow() {
    printSection("Control Flow");
    
    // If-else-if-else
    const x = 10;
    if (x > 15) {
        console.log("x is greater than 15");
    } else if (x > 5) {
        console.log("x is greater than 5 but not greater than 15");
    } else {
        console.log("x is 5 or less");
    }
    
    // Ternary operator
    const result = x > 10 ? "greater than 10" : "10 or less";
    console.log(`Ternary result: ${result}`);
    
    // Switch statement
    const day = 3;
    let dayName;
    
    switch (day) {
        case 1:
            dayName = "Monday";
            break;
        case 2:
            dayName = "Tuesday";
            break;
        case 3:
            dayName = "Wednesday";
            break;
        case 4:
            dayName = "Thursday";
            break;
        case 5:
            dayName = "Friday";
            break;
        default:
            dayName = "Weekend";
    }
    
    console.log(`Day ${day} is ${dayName}`);
    
    // For loop
    console.log("Counting from 1 to 5:");
    for (let i = 1; i <= 5; i++) {
        process.stdout.write(`${i} `);
    }
    console.log();
    
    // For...of loop (iterables)
    console.log("For...of loop with array:");
    const colors = ["red", "green", "blue"];
    for (const color of colors) {
        process.stdout.write(`${color} `);
    }
    console.log();
    
    // For...in loop (object properties)
    console.log("For...in loop with object:");
    const user = { name: "John", age: 30, role: "Admin" };
    for (const key in user) {
        console.log(`  ${key}: ${user[key]}`);
    }
    
    // While loop
    console.log("While loop counting down from 5:");
    let count = 5;
    while (count > 0) {
        process.stdout.write(`${count} `);
        count--;
    }
    console.log();
    
    // Do-while loop
    console.log("Do-while loop example:");
    let j = 1;
    do {
        process.stdout.write(`${j} `);
        j++;
    } while (j <= 5);
    console.log();
}

// Test error handling
function testErrorHandling() {
    printSection("Error Handling");
    
    // Try-catch
    try {
        const result = 10 / 0; // Not an error in JS, returns Infinity
        console.log(`10 / 0 = ${result}`);
        
        // Create an error
        // nonExistentFunction();
        console.log("This line would be skipped if error occurred above");
    } catch (error) {
        console.log(`Caught an error: ${error.message}`);
    }
    
    // Try-catch-finally
    try {
        const value = "hello";
        console.log(`No error here, value is: ${value}`);
    } catch (error) {
        console.log("This won't execute");
    } finally {
        console.log("Finally block always executes");
    }
    
    // Creating custom errors
    try {
        throw new Error("This is a custom error");
    } catch (error) {
        console.log(`Caught custom error: ${error.message}`);
    }
    
    // Custom error types
    class ValidationError extends Error {
        constructor(message) {
            super(message);
            this.name = "ValidationError";
        }
    }
    
    try {
        throw new ValidationError("Invalid input");
    } catch (error) {
        if (error instanceof ValidationError) {
            console.log(`Caught ValidationError: ${error.message}`);
        } else {
            console.log(`Caught different error: ${error.message}`);
        }
    }
}

// Test functions
function testFunctions() {
    printSection("Functions");
    
    // Function declaration
    function greet(name) {
        return `Hello, ${name}!`;
    }
    console.log(`Function declaration result: ${greet("World")}`);
    
    // Function expression
    const add = function(a, b) {
        return a + b;
    };
    console.log(`Function expression result: ${add(5, 3)}`);
    
    // Arrow function
    const multiply = (a, b) => a * b;
    console.log(`Arrow function result: ${multiply(4, 6)}`);
    
    // Default parameters
    const greetWithDefault = (name = "Guest") => `Hello, ${name}!`;
    console.log(`Function with default param: ${greetWithDefault()}`);
    console.log(`Function with provided param: ${greetWithDefault("John")}`);
    
    // Rest parameters
    const sum = (...numbers) => numbers.reduce((total, num) => total + num, 0);
    console.log(`Rest parameters sum: ${sum(1, 2, 3, 4, 5)}`);
    
    // Spread operator in function calls
    const numbers = [1, 2, 3, 4, 5];
    console.log(`Spread operator in function call: ${sum(...numbers)}`);
    
    // Closures
    function createCounter() {
        let count = 0;
        return function() {
            return ++count;
        };
    }
    
    const counter = createCounter();
    console.log(`Counter (closure) first call: ${counter()}`);
    console.log(`Counter (closure) second call: ${counter()}`);
    console.log(`Counter (closure) third call: ${counter()}`);
    
    // Immediately Invoked Function Expression (IIFE)
    const result = (function(a, b) {
        return a + b;
    })(10, 20);
    console.log(`IIFE result: ${result}`);
    
    // Function methods: call, apply, bind
    const person = {
        firstName: "John",
        lastName: "Doe",
        fullName: function() {
            return `${this.firstName} ${this.lastName}`;
        }
    };
    
    const anotherPerson = {
        firstName: "Jane",
        lastName: "Smith"
    };
    
    console.log(`Original object method: ${person.fullName()}`);
    console.log(`Using call: ${person.fullName.call(anotherPerson)}`);
    
    // Bind
    const boundFunction = person.fullName.bind(anotherPerson);
    console.log(`Using bind: ${boundFunction()}`);
}

// Test asynchronous JavaScript
function testAsynchronousJS() {
    printSection("Asynchronous JavaScript");
    
    console.log("1. Starting asynchronous tests...");
    
    // setTimeout
    setTimeout(() => {
        console.log("3. This executes after 1 second");
    }, 1000);
    
    console.log("2. After setTimeout (but executes before the timeout callback)");
    
    // Promises
    function promiseExample() {
        return new Promise((resolve, reject) => {
            // Simulating an asynchronous operation
            setTimeout(() => {
                const success = true;
                if (success) {
                    resolve("4. Promise resolved successfully");
                } else {
                    reject("Promise rejected");
                }
            }, 1500);
        });
    }
    
    promiseExample()
        .then(message => {
            console.log(message);
            
            // Promise chaining
            return "5. From promise chain";
        })
        .then(message => {
            console.log(message);
        })
        .catch(error => {
            console.error(`Error: ${error}`);
        })
        .finally(() => {
            console.log("6. Promise finally block executed");
            
            // Continue with async/await example after promises are done
            testAsyncAwait();
        });
}

// This will be called from the promises test
async function testAsyncAwait() {
    console.log("\n--- Async/Await ---");
    
    // Simple async function
    async function asyncExample() {
        return "7. Result from async function";
    }
    
    console.log(await asyncExample());
    
    // Async with await
    async function fetchData() {
        try {
            // Simulate fetch with a promise
            const result = await new Promise((resolve) => {
                setTimeout(() => resolve("8. Data retrieved successfully"), 500);
            });
            
            console.log(result);
            
            // Simulate another operation
            const processedResult = await new Promise((resolve) => {
                setTimeout(() => resolve("9. Data processed"), 300);
            });
            
            console.log(processedResult);
            
        } catch (error) {
            console.error(`Error in async function: ${error}`);
        }
    }
    
    await fetchData();
    console.log("10. Async tests completed");
    
    // Call the next test
    testModernJSFeatures();
}

// Test modern JavaScript features
function testModernJSFeatures() {
    printSection("Modern JavaScript Features");
    
    // Destructuring assignments
    // Objects
    const person = {
        name: "John",
        age: 30,
        city: "New York",
        country: "USA"
    };
    
    const { name, age, ...address } = person;
    console.log(`Destructured variables: name=${name}, age=${age}`);
    console.log(`Rest operator in destructuring: address=${JSON.stringify(address)}`);
    
    // Arrays
    const rgb = [255, 200, 150];
    const [red, green, blue] = rgb;
    console.log(`Destructured array: R=${red}, G=${green}, B=${blue}`);
    
    // Nested destructuring
    const user = {
        id: 1,
        personalInfo: {
            firstName: "Jane",
            lastName: "Doe",
            contact: {
                email: "jane@example.com",
                phone: "123-456-7890"
            }
        }
    };
    
    const { personalInfo: { firstName, contact: { email } } } = user;
    console.log(`Nested destructuring: firstName=${firstName}, email=${email}`);
    
    // Array methods
    const numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    
    // Map
    const squared = numbers.map(n => n * n);
    console.log(`Map result (squared): ${squared}`);
    
    // Filter
    const evens = numbers.filter(n => n % 2 === 0);
    console.log(`Filter result (evens): ${evens}`);
    
    // Reduce
    const sum = numbers.reduce((total, n) => total + n, 0);
    console.log(`Reduce result (sum): ${sum}`);
    
    // Find
    const found = numbers.find(n => n > 5);
    console.log(`Find result (first number > 5): ${found}`);
    
    // Every
    const allPositive = numbers.every(n => n > 0);
    console.log(`Every result (all positive): ${allPositive}`);
    
    // Some
    const hasEven = numbers.some(n => n % 2 === 0);
    console.log(`Some result (has even): ${hasEven}`);
    
    // Flat
    const nestedArray = [1, [2, 3], [4, [5, 6]]];
    console.log(`Flat result: ${nestedArray.flat()}`);
    console.log(`Flat with depth result: ${nestedArray.flat(2)}`);
    
    // FlatMap
    const sentences = ["Hello world", "JavaScript is great"];
    const words = sentences.flatMap(sentence => sentence.split(" "));
    console.log(`FlatMap result: ${words}`);
    
    // Class syntax
    class Animal {
        constructor(name) {
            this.name = name;
        }
        
        speak() {
            return `${this.name} makes a noise.`;
        }
    }
    
    class Dog extends Animal {
        constructor(name, breed) {
            super(name);
            this.breed = breed;
        }
        
        speak() {
            return `${this.name} barks.`;
        }
        
        getInfo() {
            return `${this.name} is a ${this.breed}.`;
        }
    }
    
    const dog = new Dog("Rex", "German Shepherd");
    console.log(`Class method result: ${dog.speak()}`);
    console.log(`Inherited class method: ${dog.getInfo()}`);
    
    // Private class fields (requires Node.js 12+)
    try {
        class Counter {
            #count = 0;
            
            increment() {
                this.#count++;
            }
            
            get value() {
                return this.#count;
            }
        }
        
        const counter = new Counter();
        counter.increment();
        counter.increment();
        console.log(`Private field result: counter value = ${counter.value}`);
        // This would throw an error: console.log(counter.#count);
    } catch (e) {
        console.log("Private fields not supported in this JavaScript engine");
    }
    
    // Static class members
    class MathUtils {
        static PI = 3.14159;
        
        static square(x) {
            return x * x;
        }
    }
    
    console.log(`Static property: PI = ${MathUtils.PI}`);
    console.log(`Static method: square(4) = ${MathUtils.square(4)}`);
    
    // Call next test - we're getting near the end
    testRegExpAndJSON();
}

// Test regular expressions and JSON
function testRegExpAndJSON() {
    printSection("Regular Expressions and JSON");
    
    // Regular Expressions
    const text = "The quick brown fox jumps over the lazy dog. It was 42 degrees outside.";
    
    // Simple pattern matching
    const hasQuick = /quick/.test(text);
    console.log(`/quick/ matches: ${hasQuick}`);
    
    // Using modifiers
    const caseInsensitive = /FOX/i.test(text);
    console.log(`/FOX/i (case insensitive) matches: ${caseInsensitive}`);
    
    // Character classes
    const digits = text.match(/\d+/g);
    console.log(`Digit matches: ${digits}`);
    
    const words = text.match(/\b\w{4,}\b/g); // Words with 4+ characters
    console.log(`Words with 4+ chars: ${words}`);
    
    // Replace with regex
    const censored = text.replace(/fox|dog/g, "****");
    console.log(`After replacement: ${censored}`);
    
    // Named capture groups
    const pattern = /(?<animal>\w+) jumps over/;
    const match = text.match(pattern);
    if (match && match.groups) {
        console.log(`Named group 'animal': ${match.groups.animal}`);
    }
    
    // JSON handling
    const person = {
        name: "John Doe",
        age: 30,
        isActive: true,
        address: {
            street: "123 Main St",
            city: "Anytown",
            zipCode: "12345"
        },
        hobbies: ["reading", "swimming", "coding"]
    };
    
    // Convert object to JSON string
    const jsonString = JSON.stringify(person, null, 2);
    console.log("JSON string representation:");
    console.log(jsonString);
    
    // Parse JSON string back to object
    const parsedPerson = JSON.parse(jsonString);
    console.log(`Parsed object name: ${parsedPerson.name}`);
    console.log(`Parsed object hobbies: ${parsedPerson.hobbies}`);
    
    // JSON.stringify with replacer function
    const stringifyWithReplacer = JSON.stringify(person, (key, value) => {
        if (key === "age") return value + 1; // Increment age
        if (key === "isActive") return undefined; // Remove this property
        return value;
    }, 2);
    
    console.log("JSON with replacer function:");
    console.log(stringifyWithReplacer);
    
    // Finish our testing
    calculateFibonacci();
}

// Calculate Fibonacci sequence
function calculateFibonacci() {
    printSection("Fibonacci Sequence");
    
    function fibonacci(n) {
        if (n <= 0) return [];
        if (n === 1) return [0];
        if (n === 2) return [0, 1];
        
        const result = [0, 1];
        for (let i = 2; i < n; i++) {
            result.push(result[i-1] + result[i-2]);
        }
        return result;
    }
    
    const n = 10;
    const fib = fibonacci(n);
    console.log(`First ${n} Fibonacci numbers: ${fib}`);
    
    // Final summary
    printFinalSummary();
}

// System information
function printFinalSummary() {
    printSection("System Information");
    
    console.log(`Node.js Version: ${process.version}`);
    console.log(`Platform: ${process.platform}`);
    console.log(`Architecture: ${process.arch}`);
    console.log(`Process ID: ${process.pid}`);
    console.log(`Current Directory: ${process.cwd()}`);
    console.log(`Memory Usage: ${JSON.stringify(process.memoryUsage())}`);
    console.log(`Current Date/Time: ${new Date().toISOString()}`);
    
    console.log("\n========================");
    console.log("All tests completed successfully!");
}

// Main function to run all tests
function main() {
    console.log("JAVASCRIPT CODE EXECUTION TEST");
    console.log("=============================");
    
    testBasicOperations();
    testStringOperations();
    testVariablesAndDataTypes();
    testDataStructures();
    testControlFlow();
    testErrorHandling();
    testFunctions();
    
    // Asynchronous tests will call the rest of the tests in sequence
    testAsynchronousJS();
    
    // Note: We don't need to call these directly as they'll be called from the async chain:
    // testAsyncAwait();
    // testModernJSFeatures();
    // testRegExpAndJSON();
    // calculateFibonacci();
    // printFinalSummary();
}

// Start the test
main();

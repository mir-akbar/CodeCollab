function setColor(where, newColor){
    if (where == "background") document.body.style.backgroundColor = newColor;
}
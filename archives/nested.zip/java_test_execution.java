/**
 * Java Code Execution Test File
 * ----------------------------
 * This file contains various Java operations to test code execution.
 */

import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.File;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class CodeExecutionTest {

    public static void main(String[] args) {
        System.out.println("JAVA CODE EXECUTION TEST");
        System.out.println("========================");
        
        testBasicOperations();
        testStringOperations();
        testDataStructures();
        testControlFlow();
        testExceptionHandling();
        testAdvancedMath();
        testSystemInfo();
        testFrequencyAnalysis();
        
        // Test Fibonacci
        int n = 10;
        List<Integer> fib = calculateFibonacci(n);
        System.out.println("\n=== Fibonacci Sequence ===");
        System.out.printf("First %d Fibonacci numbers: %s%n", n, fib);
        
        // Test multithreading
        testMultithreading();
        
        // Test functional programming
        testFunctionalProgramming();
        
        System.out.println("\n========================");
        System.out.println("All tests completed successfully!");
    }
    
    private static void testBasicOperations() {
        System.out.println("\n=== Basic Operations ===");
        System.out.println("Addition: 5 + 3 = " + (5 + 3));
        System.out.println("Subtraction: 10 - 4 = " + (10 - 4));
        System.out.println("Multiplication: 6 * 7 = " + (6 * 7));
        System.out.println("Division: 20 / 5 = " + (20 / 5));
        System.out.println("Integer Division: 20 / 3 = " + (20 / 3));
        System.out.println("Modulo: 20 % 7 = " + (20 % 7));
        System.out.println("Exponentiation: 2 ^ 8 = " + Math.pow(2, 8));
    }
    
    private static void testStringOperations() {
        System.out.println("\n=== String Operations ===");
        String testString = "Java is awesome!";
        System.out.println("Original string: '" + testString + "'");
        System.out.println("Length: " + testString.length());
        System.out.println("Uppercase: '" + testString.toUpperCase() + "'");
        System.out.println("Lowercase: '" + testString.toLowerCase() + "'");
        System.out.println("Replace: '" + testString.replace("awesome", "amazing") + "'");
        System.out.println("Split: " + Arrays.toString(testString.split(" ")));
        System.out.println("First 4 characters: '" + testString.substring(0, 4) + "'");
        System.out.println("String concatenation: " + "Hello " + "World");
        
        // StringBuilder example
        StringBuilder sb = new StringBuilder("Java");
        sb.append(" is").append(" flexible!");
        System.out.println("StringBuilder result: " + sb.toString());
        
        // String format
        System.out.printf("Formatted string: Name: %s, Age: %d, Height: %.2f%n", "John", 25, 1.82);
    }
    
    private static void testDataStructures() {
        System.out.println("\n=== Data Structures ===");
        
        // Array
        int[] intArray = {1, 2, 3, 4, 5};
        System.out.println("Array: " + Arrays.toString(intArray));
        
        // ArrayList
        List<String> list = new ArrayList<>();
        list.add("Java");
        list.add("Python");
        list.add("C++");
        System.out.println("ArrayList: " + list);
        list.add(1, "JavaScript");
        System.out.println("After insert: " + list);
        
        // HashMap
        Map<String, String> map = new HashMap<>();
        map.put("name", "Java");
        map.put("version", "17");
        map.put("type", "Programming Language");
        System.out.println("HashMap: " + map);
        map.put("creator", "James Gosling");
        System.out.println("After adding key: " + map);
        
        // HashSet
        Set<Integer> set = new HashSet<>();
        set.add(1);
        set.add(2);
        set.add(3);
        set.add(3); // Duplicate, won't be added
        System.out.println("HashSet (notice no duplicates): " + set);
        
        // LinkedList
        LinkedList<Character> linkedList = new LinkedList<>();
        linkedList.add('A');
        linkedList.add('B');
        linkedList.add('C');
        System.out.println("LinkedList: " + linkedList);
        linkedList.addFirst('Z');
        System.out.println("After addFirst: " + linkedList);
        
        // Queue
        Queue<String> queue = new LinkedList<>();
        queue.offer("First");
        queue.offer("Second");
        queue.offer("Third");
        System.out.println("Queue: " + queue);
        System.out.println("Queue peek: " + queue.peek());
        System.out.println("Queue poll: " + queue.poll());
        System.out.println("Queue after poll: " + queue);
        
        // Stack
        Stack<Integer> stack = new Stack<>();
        stack.push(1);
        stack.push(2);
        stack.push(3);
        System.out.println("Stack: " + stack);
        System.out.println("Stack peek: " + stack.peek());
        System.out.println("Stack pop: " + stack.pop());
        System.out.println("Stack after pop: " + stack);
    }
    
    private static void testControlFlow() {
        System.out.println("\n=== Control Flow ===");
        
        // If-else-if-else
        int x = 10;
        if (x > 15) {
            System.out.println("x is greater than 15");
        } else if (x > 5) {
            System.out.println("x is greater than 5 but not greater than 15");
        } else {
            System.out.println("x is 5 or less");
        }
        
        // Switch statement
        int day = 3;
        switch (day) {
            case 1:
                System.out.println("Monday");
                break;
            case 2:
                System.out.println("Tuesday");
                break;
            case 3:
                System.out.println("Wednesday");
                break;
            default:
                System.out.println("Other day");
        }
        
        // Enhanced switch (Java 12+)
        String dayName = switch (day) {
            case 1 -> "Monday";
            case 2 -> "Tuesday";
            case 3 -> "Wednesday";
            default -> "Other day";
        };
        System.out.println("Day name from enhanced switch: " + dayName);
        
        // For loop
        System.out.print("Counting from 1 to 5: ");
        for (int i = 1; i <= 5; i++) {
            System.out.print(i + " ");
        }
        System.out.println();
        
        // Enhanced for loop
        System.out.print("Enhanced for loop: ");
        int[] numbers = {1, 2, 3, 4, 5};
        for (int num : numbers) {
            System.out.print(num + " ");
        }
        System.out.println();
        
        // While loop
        System.out.print("While loop counting down from 5: ");
        int count = 5;
        while (count > 0) {
            System.out.print(count + " ");
            count--;
        }
        System.out.println();
        
        // Do-while loop
        System.out.print("Do-while loop example: ");
        int j = 1;
        do {
            System.out.print(j + " ");
            j++;
        } while (j <= 5);
        System.out.println();
    }
    
    private static void testExceptionHandling() {
        System.out.println("\n=== Exception Handling ===");
        
        // Try-catch
        try {
            int result = 10 / 0;
        } catch (ArithmeticException e) {
            System.out.println("Caught an exception: " + e.getMessage());
        }
        
        // Try-catch with multiple catch blocks
        try {
            String str = null;
            System.out.println(str.length());
        } catch (NullPointerException e) {
            System.out.println("Caught a NullPointerException: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Caught a generic exception");
        }
        
        // Try-catch-finally
        try {
            String value = "hello";
            System.out.println("No exception here, value is: " + value);
        } catch (Exception e) {
            System.out.println("This won't execute");
        } finally {
            System.out.println("Finally block always executes");
        }
        
        // Try with resources (Java 7+)
        try (Scanner scanner = new Scanner("test input")) {
            String input = scanner.nextLine();
            System.out.println("Read input using try-with-resources: " + input);
        } catch (Exception e) {
            System.out.println("Error reading input: " + e.getMessage());
        }
    }
    
    private static void testAdvancedMath() {
        System.out.println("\n=== Advanced Math ===");
        System.out.println("Square root of 16: " + Math.sqrt(16));
        System.out.println("Sine of 30 degrees: " + Math.sin(Math.toRadians(30)));
        System.out.println("Cosine of 60 degrees: " + Math.cos(Math.toRadians(60)));
        System.out.println("Ceiling of 4.3: " + Math.ceil(4.3));
        System.out.println("Floor of 4.8: " + Math.floor(4.8));
        System.out.println("Round of 4.5: " + Math.round(4.5));
        System.out.println("Pi constant: " + Math.PI);
        System.out.println("E constant: " + Math.E);
        System.out.println("Random number (0-1): " + Math.random());
        
        // BigInteger for arbitrary precision
        BigInteger bigInt1 = new BigInteger("1234567890123456789012345678901234567890");
        BigInteger bigInt2 = new BigInteger("9876543210987654321098765432109876543210");
        System.out.println("BigInteger sum: " + bigInt1.add(bigInt2));
        
        // BigDecimal for precise decimal calculations
        BigDecimal bd1 = new BigDecimal("0.1");
        BigDecimal bd2 = new BigDecimal("0.2");
        System.out.println("BigDecimal sum (avoiding floating-point errors): " + bd1.add(bd2));
        
        // Number formatting
        double amount = 1234567.89;
        NumberFormat formatter = NumberFormat.getCurrencyInstance();
        System.out.println("Formatted currency: " + formatter.format(amount));
    }
    
    private static void testSystemInfo() {
        System.out.println("\n=== System Information ===");
        System.out.println("Java Version: " + System.getProperty("java.version"));
        System.out.println("Java Home: " + System.getProperty("java.home"));
        System.out.println("OS Name: " + System.getProperty("os.name"));
        System.out.println("OS Version: " + System.getProperty("os.version"));
        System.out.println("User Name: " + System.getProperty("user.name"));
        System.out.println("Current Directory: " + System.getProperty("user.dir"));
        System.out.println("Available Processors: " + Runtime.getRuntime().availableProcessors());
        System.out.println("Free Memory (bytes): " + Runtime.getRuntime().freeMemory());
        System.out.println("Total Memory (bytes): " + Runtime.getRuntime().totalMemory());
        
        // Current date/time
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        System.out.println("Current Date/Time: " + now.format(formatter));
        
        // List files in current directory
        File currentDir = new File(".");
        System.out.println("Files in current directory:");
        File[] files = currentDir.listFiles();
        if (files != null) {
            for (int i = 0; i < Math.min(files.length, 5); i++) {
                System.out.println("  " + files[i].getName());
            }
            if (files.length > 5) {
                System.out.println("  ... and " + (files.length - 5) + " more files");
            }
        }
    }
    
    private static Map<String, Integer> wordFrequency(String text) {
        if (text == null || text.isEmpty()) {
            return new HashMap<>();
        }
        
        String[] words = text.toLowerCase().split("\\s+");
        Map<String, Integer> frequencies = new HashMap<>();
        
        for (String word : words) {
            // Remove punctuation
            word = word.replaceAll("[^a-zA-Z]", "");
            if (!word.isEmpty()) {
                frequencies.put(word, frequencies.getOrDefault(word, 0) + 1);
            }
        }
        
        return frequencies;
    }
    
    private static void testFrequencyAnalysis() {
        System.out.println("\n=== Text Analysis ===");
        String sampleText = "This is a sample text. This text is used for demonstration purposes. Sample text can be any text.";
        Map<String, Integer> frequencies = wordFrequency(sampleText);
        
        System.out.println("Word frequencies:");
        
        // Sort by frequency (descending)
        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(frequencies.entrySet());
        sortedEntries.sort(Map.Entry.<String, Integer>comparingByValue().reversed());
        
        for (Map.Entry<String, Integer> entry : sortedEntries) {
            System.out.println("  " + entry.getKey() + ": " + entry.getValue());
        }
    }
    
    private static List<Integer> calculateFibonacci(int n) {
        List<Integer> fibSequence = new ArrayList<>();
        if (n <= 0) return fibSequence;
        
        fibSequence.add(0);
        if (n == 1) return fibSequence;
        
        fibSequence.add(1);
        for (int i = 2; i < n; i++) {
            fibSequence.add(fibSequence.get(i-1) + fibSequence.get(i-2));
        }
        
        return fibSequence;
    }
    
    private static void testMultithreading() {
        System.out.println("\n=== Multithreading ===");
        
        // Simple thread creation
        Thread thread1 = new Thread(() -> {
            try {
                System.out.println("Thread 1 started");
                Thread.sleep(100);
                System.out.println("Thread 1 finished");
            } catch (InterruptedException e) {
                System.out.println("Thread 1 interrupted");
            }
        });
        
        Thread thread2 = new Thread(() -> {
            try {
                System.out.println("Thread 2 started");
                Thread.sleep(50);
                System.out.println("Thread 2 finished");
            } catch (InterruptedException e) {
                System.out.println("Thread 2 interrupted");
            }
        });
        
        thread1.start();
        thread2.start();
        
        try {
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted");
        }
        
        // Atomic operations
        AtomicInteger atomicCounter = new AtomicInteger(0);
        System.out.println("AtomicInteger initial value: " + atomicCounter.get());
        atomicCounter.incrementAndGet();
        System.out.println("AtomicInteger after increment: " + atomicCounter.get());
        
        System.out.println("Multithreading test completed");
    }
    
    private static void testFunctionalProgramming() {
        System.out.println("\n=== Functional Programming ===");
        
        // Lambda expression with functional interface
        List<String> languages = Arrays.asList("Java", "Python", "JavaScript", "C#", "Go");
        
        // Stream API
        System.out.println("Filtered languages (contains 'a'):");
        languages.stream()
            .filter(lang -> lang.contains("a"))
            .forEach(lang -> System.out.println("  " + lang));
        
        // Map operation
        System.out.println("Mapped to lengths:");
        List<Integer> lengths = languages.stream()
            .map(String::length)
            .collect(Collectors.toList());
        System.out.println("  " + lengths);
        
        // Reduce operation
        int sum = languages.stream()
            .mapToInt(String::length)
            .sum();
        System.out.println("Sum of all lengths: " + sum);
        
        // IntStream
        System.out.println("Sum of numbers 1 to 10: " + 
            IntStream.rangeClosed(1, 10).sum());
        
        // Optional
        Optional<String> longestLanguage = languages.stream()
            .max(Comparator.comparing(String::length));
        System.out.println("Longest language: " + 
            longestLanguage.orElse("No language found"));
    }
}
